package com.snhu.wareflow;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.MyViewHolder> {

    private ArrayList<Item> itemList;

    public recyclerAdapter(ArrayList<Item> itemsList){
        this.itemList = itemsList;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView nameText;
        private TextView itemDesc;
        private TextView itemQty;


        public MyViewHolder(final View view){
            super(view);
            nameText = view.findViewById(R.id.itemNumber);
            itemDesc = view.findViewById(R.id.itemDesc);
            itemQty = view.findViewById(R.id.itemQty);
        }
    }

    @NonNull
    @Override
    public recyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items, parent, false);
        return new MyViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(@NonNull recyclerAdapter.MyViewHolder holder, int position) {
        String name = itemList.get(position).getItem();
        String desc = itemList.get(position).getDesc();
        String qty = itemList.get(position).getQty();
        holder.nameText.setText(name);
        holder.itemDesc.setText(desc);
        holder.itemQty.setText(qty);

    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
