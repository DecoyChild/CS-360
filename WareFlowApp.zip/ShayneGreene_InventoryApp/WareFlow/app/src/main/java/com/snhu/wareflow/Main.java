package com.snhu.wareflow;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Main extends AppCompatActivity {
    private ArrayList<Item> itemsList;
    private RecyclerView recyclerView;
    ImageButton imgButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sms_permission);
        getSupportActionBar().hide();

        // The code below is for testing each layout on my phone.
        // I just activated the parts I needed so I didnt have to jump to each screen

//        setContentView(R.layout.dashboard);
//        setContentView(R.layout.update_item);

//        setContentView(R.layout.inventory_grid);
//        itemsList = new ArrayList<>();
//        recyclerView = findViewById(R.id.recView);
//
//        setItemInfo();
//        setAdapter();

//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        this.getWindow().setFlags((WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN));

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

//        TextView resetPass = (TextView) findViewById(R.id.resetPass);
//        resetPass.setMovementMethod(LinkMovementMethod.getInstance());

    }

    private void setAdapter() {
        recyclerAdapter adapter = new recyclerAdapter(itemsList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void setItemInfo() {
        itemsList.add(new Item("PANPN18-14R-3K", "Contacts", "3000"));
        itemsList.add(new Item("MOL08-20-0105", "More Contacts for another item", "12000"));
        itemsList.add(new Item("MOL43030-0002", "This is the third Contact", "6000"));
        itemsList.add(new Item("MOL43030-0001", "This is the forth Contact", "67000"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_home) {
            return true;
        }else if (id == R.id.menu_logout){
            finishAffinity();
        }


        return super.onOptionsItemSelected(item);
    }
}
