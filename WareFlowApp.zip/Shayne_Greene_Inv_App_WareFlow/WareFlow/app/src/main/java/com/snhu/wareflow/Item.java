package com.snhu.wareflow;

/**
 *  Item class for the recylcler view
 */
public class Item {
    String item;
    String desc;
    String qty;

    public Item(String item, String desc, String qty){
        this.item = item;
        this.desc = desc;
        this.qty = qty;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }
}
