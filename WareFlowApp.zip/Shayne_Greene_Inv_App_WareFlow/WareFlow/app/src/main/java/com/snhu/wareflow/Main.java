package com.snhu.wareflow;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;

import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Main extends BaseActivity {
    private ArrayList<Item> itemsList;
    private RecyclerView recyclerView;

    EditText textLogin;
    EditText textPassword;
    TextView resetPass;
    DatabaseManager dbManager;

    ImageButton imgButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login);
        getSupportActionBar().hide(); // hiding the action bar from the login window

        //setting up sharedpref for the username so I can grab it from any activity
        SharedPreferences settings = getSharedPreferences("USERNAME", 0);

        // initializing controllers
        textLogin = (EditText) findViewById(R.id.loginUsername);
        textPassword = (EditText) findViewById(R.id.loginPassword);

        // Creating / getting an instance of a database manager
        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }

        // the link to reset a password. Now it only goes to google.com
        resetPass = (TextView) findViewById(R.id.resetPass);
        resetPass.setMovementMethod(LinkMovementMethod.getInstance());

    }

    /**
     * LOGIN BUTTON PRESSED
     * @param view
     */
    public void btnLoginPressed(View view){
        // Get the user input from fields
        String username = textLogin.getText().toString();
        String password = textPassword.getText().toString();

        // Getting the cursor to the first record found (should never be more than one)
        Cursor cursor = dbManager.fetchUser(username);
        if (cursor.getCount() == 0) {
            Toast.makeText(this,"Username not found. Please sign up first", Toast.LENGTH_SHORT).show();
        }else if (cursor != null) {
            // If the users exists - Getting the password from database
            int passwordIndex = cursor.getColumnIndex(DatabaseHelper.PASSWORD);
            int smsIndex = cursor.getColumnIndex(DatabaseHelper.SMS);
            String databasePassword = cursor.getString(passwordIndex).trim();
            String sms = cursor.getString(smsIndex);

            // Check if the passwords match
            if (databasePassword.equals(password)) {
                // Setting up the shared preferences for the username
                SharedPreferences prefs = getSharedPreferences("USERNAME", 0);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("user", username);
                editor.apply();

                // chencking if the permissions have already been prompted
                // NOTE -- SMS permissions were DENIED by default, so if a user denied
                // a prompt would always show to allow.
                if (!sms.isBlank()){
                    // if the permission is granted or denied we want to go to the dashboard
                    Intent intent = new Intent(this, DashboardActivity.class);
                    startActivity(intent);
                }else{
                    // Show the permissions screen if nothing has been set
                    Intent intent = new Intent(this, SmsPermissions.class);
                    intent.putExtra("USERNAME", username);
                    startActivity(intent);
                }
            } else {
                // When the passwords dont match
                Toast.makeText(this, "Passwords Dont Match", Toast.LENGTH_SHORT).show();
            }
        }


    }

    /**
     *  SIGN UP BUTTON PRESSED
     * @param view
     */
    public void btnSignupPressed(View view){
        // Check if user exists
        Cursor cursor = dbManager.fetchUser(textLogin.getText().toString());

        //if the user doesnt exist, load user into USERS table
        if (cursor.getCount() == 0){
            String username = textLogin.getText().toString().trim();
            String password = textPassword.getText().toString().trim();
            String sms = "";
            if (username.length() > 3 && password.length() >= 8) {
                // Insert the user
                dbManager.insertUser(username, password, sms);
                Toast.makeText(this, "User was added...Please Login", Toast.LENGTH_SHORT).show();

                // Clearing the fields and setting the pointer to the Username field
                textLogin.setText("");
                textPassword.setText("");
                textLogin.requestFocus();
                cursor.close();
            }else{
                // Display certain messages depending on the
                if (username.isBlank() && password.isBlank()){
                    createDialog("Please enter a username and password to Sign Up").show(); // Show a popup dialog rather than a toast
                }else if (username.length() <= 3){
                    Toast.makeText(this,"Username must contain at least 3 characters", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this,"Please provide a password of at least 8 characters", Toast.LENGTH_SHORT).show();
                }
            }
        }else{
            // If the username already exists do nothing
            Toast.makeText(this,"Username already exists. Please login", Toast.LENGTH_SHORT).show();
        }
    }

}
