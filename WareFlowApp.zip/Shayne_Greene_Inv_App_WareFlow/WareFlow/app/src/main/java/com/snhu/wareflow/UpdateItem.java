package com.snhu.wareflow;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateItem extends BaseActivity {

    EditText itemNumber;
    EditText description;
    EditText quantity;
    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.update_item);

        // Setting the action bar title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Add / Modify Item");
        }

        // These are used when coming from the View Inventory view
        String itemNum = getIntent().getStringExtra("ITEM_NUM");
        String desc = getIntent().getStringExtra("DESCRIPTION");
        String qty = getIntent().getStringExtra("QUANTITY");

        itemNumber = (EditText) findViewById(R.id.itemNumberInven);
        description = (EditText) findViewById(R.id.itemDescription);
        quantity = (EditText) findViewById(R.id.itemQtyInven);

        // If the getIntent extra existis, set the fields
        if (itemNum != null && !itemNum.isBlank()){itemNumber.setText(itemNum);}
        if (desc != null && !desc.isBlank()){description.setText(desc);}
        if (qty != null && !qty.isBlank()){quantity.setText(qty);}

        // getting an instance of the database manager
        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * The Add / Update item button pressed
     *  It will either add a new item or update an exiting one
     *  TODO - Future builds: Load Description and qty data if the part onEdit is found
     * @param view
     */
    public void btnAddItemPressed(View view){
        // get the field data

        String newItemNumber = itemNumber.getText().toString().trim();
        String newDescription = description.getText().toString().trim();
        String itemQuantity = quantity.getText().toString().trim();

        // If all the fields have some data
        if (!newItemNumber.isBlank() && !newDescription.isBlank() && !itemQuantity.isBlank()) {
            Integer itemQty = Integer.parseInt(itemQuantity);

            // Get the item to see if it exists
            Cursor cursor = dbManager.fetchItem(newItemNumber);
            if (cursor != null && cursor.getCount() == 0) {
                // Item does not exist - Insert the item to the ITEMS table
                dbManager.insertItem(newItemNumber, newDescription, itemQty);
                Toast.makeText(this, "Item has been added.", Toast.LENGTH_LONG).show();
                clearFields();
                itemNumber.requestFocus();
                cursor.close();
                if (itemQty <= 0 ){
                    // Checking for permissions setting on SMS and serding if GRANTED
                    if (getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendZeroInventorySMS(newItemNumber);
                    }
                }
            }else{
                // If the part exists, then update the new values
                int updated = dbManager.updateItem(newItemNumber, newDescription, itemQty);
                if (updated > 0 ){
                    clearFields();
                    itemNumber.requestFocus();
                    Toast.makeText(this, "Item has been updated.", Toast.LENGTH_LONG).show();
                    if (getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendZeroInventorySMS(newItemNumber);
                    }
                }
            }
        }else{
            // If there is nothibg filled out on the forms
            Toast.makeText(this, "Please complete form", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Finish the activity and return to the previous screen
     * @param view
     */
    public void btnCancel(View view){
        finish();
    }

    /**
     * Remove an item from the inventory / items table
     * @param view
     */
    public void btnRemoveItemPressed(View view){

        String remItemNumber = itemNumber.getText().toString().trim();

        if (!remItemNumber.isBlank()) {
            // Get a cursor to the item
            Cursor cursor = dbManager.fetchItem(remItemNumber);
            if (cursor != null && cursor.getCount() > 0) {
                // get the _id field for the item
                int idIndex = cursor.getColumnIndex(DatabaseHelper.ITEM_ID);
                long itemId = cursor.getLong(idIndex);

                // delete the item
                Integer deleted = dbManager.deleteItem(itemId);

                // returns the rows affected
                if (deleted >= 1) {
                    Toast.makeText(this, "Item was deleted!", Toast.LENGTH_SHORT).show();
                    clearFields();
                    itemNumber.requestFocus();
                    cursor.close();
                } else {
                    Toast.makeText(this, "Item was NOT deleted!", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Please enter an item to delete.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Simple method to clear the fields
     */
    public void clearFields(){
        itemNumber.setText("");
        description.setText("");
        quantity.setText("");
    }



}