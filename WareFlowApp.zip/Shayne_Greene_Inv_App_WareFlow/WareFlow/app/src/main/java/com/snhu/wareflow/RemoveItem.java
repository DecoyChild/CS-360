package com.snhu.wareflow;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RemoveItem extends BaseActivity {
    EditText item;
    Button remove;
    Button done;
    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.remove_item);

        // setting up the controllers
        item = (EditText) findViewById(R.id.itemNumberDelete);
        remove = (Button) findViewById(R.id.itemDelete);
        done = (Button) findViewById(R.id.doneDelete);

        // Setting the Action bar title
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Remove Item");
        }

        // Creating / getting an instance of the Database Manager
        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * REMOVE BUTTON PRESSED
     *  The delete query takes a part number that is to be removed
     * @param view
     */

    public void btnRemovePressed(View view){

        String itemToRemove = item.getText().toString().trim();

        // Will only process if there is text
        if (!itemToRemove.isBlank()){
            Cursor cursor = dbManager.fetchItem(itemToRemove);
            if (cursor != null && cursor.getCount() > 0) {

                // getting the index of the _id column
                int idIndex = cursor.getColumnIndex(DatabaseHelper.ITEM_ID);
                long itemId = cursor.getLong(idIndex);

                // Deleting the item - returns number of rows affected
                Integer deleted = dbManager.deleteItem(itemId);
                if (deleted >= 1) {
                    Toast.makeText(this, "Item was deleted!", Toast.LENGTH_SHORT).show();
                    finish(); // return to the activity that called this
                } else {
                    // Show a message if nothing was removed
                    Toast.makeText(this, "Item was NOT deleted!", Toast.LENGTH_SHORT).show();
                }
            }else{
                // If the cursor returns nothing
                Toast.makeText(this, "Item not found", Toast.LENGTH_SHORT).show();
            }
        }else{
            // Simple prompt if nothing was entered in the part field
            Toast.makeText(this, "Please Enter an Item Number", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * DONE BUTTON PRESSED
     *  - Simply returns to the previous activity
     * @param view
     */
    public void btnDoneRemovePressed(View view){
        finish();
    }
}