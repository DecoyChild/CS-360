package com.snhu.wareflow;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class DashboardActivity extends BaseActivity {
    // Getting the username in case there are logs that i want to add on who made changes
    Button zeroStock;
    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.dashboard);
        zeroStock = (Button) findViewById(R.id.zeroStock);

        // get the username from shared preferences
        SharedPreferences prefs = this.getSharedPreferences("USERNAME", MODE_PRIVATE);
        String username = prefs.getString("user", "default_value_if_not_found");

        getSupportActionBar().show();

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            getSupportActionBar().setDisplayShowHomeEnabled(false);

            getSupportActionBar().setTitle("Welcome " + username);
        }
        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }
        // Find all items with zero inventory
        Integer zeroStockCount = getZeroStockItemsCount();
        zeroStock.setText(zeroStockCount.toString());

    }

    // Buttons that will take users to the respective activities
    // view inventory button
    public void btnViewInventoryPressed(View view){
        Intent intent = new Intent(this, ItemGrid.class);
        startActivity(intent);
    }
    // these three will open the same window
    // Add Item Button
    public void btnAddItemPressed(View view){
        Intent intent = new Intent(this, UpdateItem.class);
        startActivity(intent);
    }
    // remove Item Button

    public void btnRemoveItem(View view){
        Intent intent = new Intent(this, RemoveItem.class);
        startActivity(intent);
    }

    // adjust inventory button
    public void btnAdjustInventory(View view){
        Intent intent = new Intent(this, AdjustInventory.class);
        startActivity(intent);
    }

    public void btnZeroInventoryPressed(View view){
        Intent intent = new Intent(this, ItemGrid.class);
        intent.putExtra("from_activity", "zero_inventory");
        startActivity(intent);
    }

    public Integer getZeroStockItemsCount(){
        Integer count = 0;
        Cursor cursor = dbManager.fetchAllItems();
        if (cursor != null && cursor.getCount() > 0) {
            while(cursor.moveToNext()){
                int quantityIndex = cursor.getColumnIndex(DatabaseHelper.QUANTITY);
                int itemQuantity = cursor.getInt(quantityIndex);
                if (itemQuantity == 0){
                    count += 1;
                }
            }

        }
        return count;
    }
}