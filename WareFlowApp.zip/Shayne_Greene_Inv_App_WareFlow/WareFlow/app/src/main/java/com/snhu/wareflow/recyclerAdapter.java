package com.snhu.wareflow;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recyclerAdapter extends RecyclerView.Adapter<recyclerAdapter.MyViewHolder> {

    private ArrayList<Item> itemList;
    private OnItemClickListener listener;

    public recyclerAdapter(ArrayList<Item> itemsList,OnItemClickListener listener){
        this.itemList = itemsList;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onEditClick(Item item);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView nameText;
        private TextView itemDesc;
        private TextView itemQty;
        ImageButton btnEdit;

        public MyViewHolder(final View view){
            super(view);
            nameText = view.findViewById(R.id.itemNumberInven);
            itemDesc = view.findViewById(R.id.itemDesc);
            itemQty = view.findViewById(R.id.itemQtyInven);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }

    @NonNull
    @Override
    public recyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items, parent, false);
        return new MyViewHolder(itemView);

    }

    /**
     *
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Item item = itemList.get(position);

        holder.nameText.setText(item.getItem());
        holder.itemDesc.setText(item.getDesc());
        holder.itemQty.setText(item.getQty());

        // Carries the vales at that index to the update Item activity
        holder.btnEdit.setOnClickListener(v -> {

            Intent intent = new Intent(v.getContext(), UpdateItem.class);

            intent.putExtra("ITEM_NUM", item.getItem());
            intent.putExtra("DESCRIPTION", item.getDesc());
            intent.putExtra("QUANTITY", item.getQty());

            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
