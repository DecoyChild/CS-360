package com.snhu.wareflow;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemGrid extends BaseActivity {

    private ArrayList<Item> itemsList;
    private RecyclerView recyclerView;
    private Button addFromGrid;
    private String fromActivity;

    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.inventory_grid);

        fromActivity = getIntent().getStringExtra("from_activity");

        // Changes the Action bar text to Zero or All inventory depending on what activity invoked
        if (getSupportActionBar() != null){
            if (fromActivity != null && fromActivity.equals("zero_inventory")){
                getSupportActionBar().setTitle("Zero Inventory Items");
            }else{
                getSupportActionBar().setTitle("All Inventory Items");
            }
        }

        itemsList = new ArrayList<>();
        recyclerView = findViewById(R.id.recView);
        addFromGrid = (Button) findViewById(R.id.addFromGrid);

        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }

        setItemInfo();
        setAdapter();
    }
    @Override
    protected void onResume() {
        super.onResume();
        // After an update / finish from another activity, this will refresh the grid
        setItemInfo();
        setAdapter();
    }

    private void setAdapter() {

        recyclerAdapter adapter = new recyclerAdapter(itemsList, item ->{
            Intent intent = new Intent(ItemGrid.this, UpdateItem.class);
            intent.putExtra("ITEM_NUM", item.getItem());
            intent.putExtra("DESCRIPTION", item.getDesc());
            intent.putExtra("QUANTITY", item.getQty());
        });
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    /**
     *  Fill the recycler view with all items in the database
     *  Or all zero qty items  depending on where it was called from
     */
    private void setItemInfo() {
        itemsList.clear();
        try {

            // Always get all the items
            //  TODO  --  Not tested with larger datasets.
            Cursor cursor = dbManager.fetchAllItems();

            // looping through all the items
            while(cursor.moveToNext()){
                int itemIndex = cursor.getColumnIndex(DatabaseHelper.ITEM_NUM);
                int descIndex = cursor.getColumnIndex(DatabaseHelper.DESCRIPTION);
                int qtyIndex = cursor.getColumnIndex(DatabaseHelper.QUANTITY);
                String nextItem = cursor.getString(itemIndex);
                String nextDesc = cursor.getString(descIndex);
                String nextQty = String.valueOf(cursor.getInt(qtyIndex));

                // if the Zero inventoty button was pressed,only show the rows with 0 inventory
                if (fromActivity != null && fromActivity.equals("zero_inventory")){

                    int testQuantity = cursor.getInt(qtyIndex);
                    if (testQuantity == 0){
                        // items with 0 inventory
                        itemsList.add(new Item(nextItem, nextDesc, nextQty));
                    }
                }else{
                    // all items
                    itemsList.add(new Item(nextItem, nextDesc, nextQty));
                }
            }
            cursor.close();
        } catch (SQLiteException e){
            e.printStackTrace();
        }
    }

    /**
     * Button to add an item from the grid layout page
     * @param view
     */
    public void btnAddItemFromGridPressed(View view){
        Intent intent = new Intent(this, UpdateItem.class);
        startActivity(intent);
    }

}