package com.snhu.wareflow;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsPermissions extends BaseActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private Button cont;
    private Button setPermission;
    private DatabaseManager dbManager;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.sms_permission);
        getSupportActionBar().hide();

        SharedPreferences prefs = this.getSharedPreferences("USERNAME", MODE_PRIVATE);
        username = prefs.getString("user", "");

        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }

        setPermission = (Button) findViewById(R.id.sms_allow);
        setPermission.setVisibility(View.VISIBLE);

        cont = (Button) findViewById(R.id.cont);
        cont.setVisibility(View.INVISIBLE);
    }

    /**
     * (this comment was automatically generated)
     * @param requestCode The request code passed in {@link #requestPermissions}.
     * @param permissions The requested permissions. Never null.
     * @param grantResults The grant results for the corresponding permissions which is either
     *                     {@link android.content.pm.PackageManager#PERMISSION_GRANTED} or
     *                     {@link android.content.pm.PackageManager#PERMISSION_DENIED}. Never null.
     * @param deviceId The deviceId for which permissions were requested. The primary/physical
     *                 device is assigned {@link Context#DEVICE_ID_DEFAULT}, and virtual devices
     *                 are assigned unique device Ids.
     *
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults, int deviceId) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults, deviceId);
        if (requestCode == SMS_PERMISSION_CODE){
            int updated = dbManager.updateUserSMS(username, "NOTIFIED");
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                // permissoin granted
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                Toast.makeText(this, "Press Continue", Toast.LENGTH_SHORT).show();
            } else {
                // permission denied
                // Once the SMS was denied, users will need to change in the App Info section
                createDialog("To Enable, You must goto the App Info settings.\nIn the App Permissions look for SMS in the \nNot Allowed section." +
                        "\n\nPress Continue on next screen....").show();
            }
        }
    }

    /**
     * Button press to set the prompt for permission
     * @param view
     */
    public void btnSetPermission(View view){
        // Sends the prompt for Approve or Deny
        requestPermissions(new String[] {Manifest.permission.SEND_SMS},SMS_PERMISSION_CODE);

        // Toggling buttons for easier redirect to next screen
        setPermission.setVisibility(View.INVISIBLE);
        cont.setVisibility(View.VISIBLE);
    }

    /**
     * For Continue button
     * @param view
     */
    public void btnContinue(View view){
        // Go to the dashboard
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
    }
}