package com.snhu.wareflow;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static DatabaseHelper instance;

    static final String DATABASE_NAME = "WAREFLOW.DB";
    static final int DATABASE_VERSION = 1;

    static final String ITEM_TABLE = "ITEMS";
    static final String ITEM_ID = "_ID";
    static final String ITEM_NUM = "item_number";
    static final String DESCRIPTION = "description";
    static final String QUANTITY = "quantity";

    static final String USER_TABLE = "USERS";
    static final String USER_ID = "_id";
    static final String USERNAME = "username";
    static final String PASSWORD = "password";
    static final String SMS = "sms_permission";

    // Setting the queries for the tables
    private static final String CREATE_ITEM_DB_QUERY = "CREATE TABLE " + ITEM_TABLE + " ( " + ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + ITEM_NUM + " TEXT NOT NULL, " + DESCRIPTION + " TEXT, " + QUANTITY + " INTEGER );";
    private static final String CREATE_ITEM_INDEX = "CREATE INDEX idx_item_num ON " + ITEM_TABLE + " (" + ITEM_NUM + ");";
    private static final String CREATE_USER_DB_QUERY = "CREATE TABLE " + USER_TABLE + " ( "+USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + USERNAME + " TEXT NOT NULL, " + PASSWORD + " TEXT NOT NULL, " + SMS +" TEXT);";
    private static final String CREATE_USERNAME_INDEX = "CREATE INDEX idx_username ON " + USER_TABLE + " (" + USERNAME + ");";

    /**
     * Creating a singleton class for the DBHelper to ensure only one instance is created and used
     * by all activities.
     * @param context
     * @return
     */
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper( Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Executing the creation
     * @param db The database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ITEM_DB_QUERY);
        db.execSQL(CREATE_ITEM_INDEX);
        db.execSQL(CREATE_USER_DB_QUERY);
        db.execSQL(CREATE_USERNAME_INDEX);
    }

    /**
     *
     * @param db The database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + ITEM_TABLE);
    }
}
