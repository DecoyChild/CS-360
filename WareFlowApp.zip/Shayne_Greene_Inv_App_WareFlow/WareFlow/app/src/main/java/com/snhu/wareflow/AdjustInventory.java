package com.snhu.wareflow;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.service.credentials.BeginGetCredentialOption;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AdjustInventory extends BaseActivity {

    private Boolean partLoaded = false;

    EditText item;
    EditText qty;
    Button load;
    Button adjust;
    Button done;
    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.update_item_inventory);

        // setting up the controllers
        item = (EditText) findViewById(R.id.itemNumberInven);
        qty = (EditText) findViewById(R.id.itemQtyInven);
        load = (Button) findViewById(R.id.loadInven);
        adjust = (Button) findViewById(R.id.saveButtonInven);
        done = (Button) findViewById(R.id.cancelButtonInven);

        getSupportActionBar().show();

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Adjust Inventory");
        }

        // get an instance of the database manager
        dbManager = DatabaseManager.getInstance(this);
        try{
            dbManager.open();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Update the quantity
     * @param view
     */
    public void btnAdjustPressed(View view){
        // If the partLoaded flag is set to true
        if (partLoaded){
            String itemNumber = item.getText().toString().trim();
            String quantity = qty.getText().toString().trim();
            Integer itemQty = Integer.parseInt(quantity);
            int rowCount = dbManager.updateItemQuantity(itemNumber,itemQty);
            if (rowCount > 0 ) {

                // if the quantity is set to zero, send an SMS if permission is GRANTED
                if (itemQty <= 0) {
                    if (getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendZeroInventorySMS(itemNumber);
                    }
                }
                Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show();
                finish();
            }else{
                Toast.makeText(this, "Nothing was updated", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Item must be loaded first!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Load the part data / qty to make sure the part sxists and to see the quantity as it stands
     * @param view
     */
    public void btnLoadItemPressed(View view){
        String itemNumber = item.getText().toString().trim();
        if (!itemNumber.isBlank()){
            Cursor cursor = dbManager.fetchItem(itemNumber);
            if (cursor != null && cursor.getCount() > 0) {
                // if the part exists, the load the info
                int qtyIndex = cursor.getColumnIndex(DatabaseHelper.QUANTITY);
                String ogQuantity = cursor.getString(qtyIndex);
                qty.setText(ogQuantity);
                partLoaded = true;
            }

        }
    }

    public void btnDone(View view){
        finish();
    }

}