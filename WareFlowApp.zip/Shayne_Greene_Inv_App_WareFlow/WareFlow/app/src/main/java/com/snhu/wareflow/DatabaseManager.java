package com.snhu.wareflow;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLDataException;

public class DatabaseManager {
    private static DatabaseManager instance;
    private DatabaseHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    private DatabaseManager(Context ctx){
        context = ctx;
    }

    /**
     * Creating a singleton class to avoiding creating multiple dbMnager objects for each activity.
     * Creating one instance that can be obtained from each activity
     * @param ctx
     * @return
     */
    public static synchronized DatabaseManager getInstance(Context ctx) {
        if (instance == null) {
            instance = new DatabaseManager(ctx);
        }
        return instance;
    }

    /**
     *
     * @return
     * @throws SQLDataException
     */
    public DatabaseManager open() throws SQLDataException {
        dbHelper = DatabaseHelper.getInstance(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    /**
     * Default insert for user at signup
     * @param username
     * @param password
     * @param sms
     */
    public void insertUser(String username, String password, String sms){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.USERNAME, username);
        contentValues.put(DatabaseHelper.PASSWORD, password);
        contentValues.put(DatabaseHelper.SMS, sms);
        database.insert(DatabaseHelper.USER_TABLE, null, contentValues);
    }

    /**
     *  Get the user data from the database from the username
     * @param username
     * @return
     */
    public Cursor fetchUser(String username){
        String [] columns = new String [] {DatabaseHelper.USER_ID, DatabaseHelper.USERNAME, DatabaseHelper.PASSWORD, DatabaseHelper.SMS};
        String selection = DatabaseHelper.USERNAME + " = ?";
        String[] selArgs = {username};
        Cursor cursor = database.query(DatabaseHelper.USER_TABLE, columns, selection, selArgs, null, null,null);
         if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    /**
     * Update the user sms notificaton status
     * @param username
     * @param sms
     * @return
     */
    public int updateUserSMS(String username, String sms){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.SMS, sms);
        String selection = DatabaseHelper.USERNAME + " = ?";
        String[] selArgs = {username};
        return  database.update(DatabaseHelper.USER_TABLE, contentValues,selection,selArgs);

    }

    /**
     * DELETE USER - not used yet
     * @param _id
     */
    public void deleteUser(long _id) {
        database.delete(DatabaseHelper.USER_TABLE, DatabaseHelper.USER_ID + " = " + _id, null);

    }

    /**
     * Default insert for a new item
     * @param item
     * @param description
     * @param quantity
     */
    public void insertItem(String item, String description, Integer quantity){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.ITEM_NUM, item);
        contentValues.put(DatabaseHelper.DESCRIPTION, description);
        contentValues.put(DatabaseHelper.QUANTITY, quantity);
        database.insert(DatabaseHelper.ITEM_TABLE, null, contentValues);
    }

    /**
     * Get all columns for an Item
     * @param itemNum
     * @return
     */
    public Cursor fetchItem(String itemNum){
        String [] columns = new String [] {DatabaseHelper.ITEM_ID, DatabaseHelper.ITEM_NUM, DatabaseHelper.DESCRIPTION, DatabaseHelper.QUANTITY};
        String selection = DatabaseHelper.ITEM_NUM + " = ?";
        String[] selArgs = {itemNum};
        Cursor cursor = database.query(DatabaseHelper.ITEM_TABLE, columns, selection, selArgs, null, null,null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    /**
     * Update the quantity for a single item
     * @param item
     * @param quantity
     * @return
     */
    public int updateItemQuantity(String item, Integer quantity){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.QUANTITY, quantity);
        String selection = DatabaseHelper.ITEM_NUM + " = ?";
        String[] selArgs = {item};
        return database.update(DatabaseHelper.ITEM_TABLE,contentValues,selection,selArgs);
    }

    /**
     * Delete an item
     *
     * @param _id
     * @return
     */
    public Integer deleteItem(long _id){
        return database.delete(DatabaseHelper.ITEM_TABLE, DatabaseHelper.ITEM_ID + " = " + _id, null);
    }

    /**
     * Get all the items from the database
     * @return
     */
    public Cursor fetchAllItems(){
        String [] columns = new String [] {DatabaseHelper.ITEM_ID, DatabaseHelper.ITEM_NUM, DatabaseHelper.DESCRIPTION, DatabaseHelper.QUANTITY};

        Cursor cursor = database.query(DatabaseHelper.ITEM_TABLE, columns, null, null, null, null,null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    /**+
     * Update item fields
     *
     * @param item
     * @param description
     * @param quantity
     * @return
     */
    public int updateItem(String item, String description, Integer quantity){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.DESCRIPTION, description);
        contentValues.put(DatabaseHelper.QUANTITY, quantity);
        String selection = DatabaseHelper.ITEM_NUM + " = ?";
        String[] selArgs = {item};
        return database.update(DatabaseHelper.ITEM_TABLE,contentValues,selection,selArgs);
    }

}



// Tossing this guy here for a reference

/*
Cursor cursor = db.query(
    "table_name",   // Table name
    columns,        // Columns to return
    selection,      // WHERE clause
    selectionArgs,  // WHERE clause arguments
    null,           // groupBy
    null,           // having
    orderBy,        // orderBy
    limit           // limit
);
 */