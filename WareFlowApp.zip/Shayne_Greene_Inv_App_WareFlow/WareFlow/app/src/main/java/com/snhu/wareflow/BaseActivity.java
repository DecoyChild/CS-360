package com.snhu.wareflow;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Added a base activity to hold methods that can be used throughout the app as long as the
 * activity extends the BaseActivity
 */
public abstract class BaseActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    /**
     * Method to control actions for the menu list
     * @param item The menu item that was selected.
     *
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_home) {
            Intent intent = new Intent(this, DashboardActivity.class);
            startActivity(intent);
            return true;
        }else if (id == R.id.menu_add_item) {
            Intent intent = new Intent(this, UpdateItem.class);
            startActivity(intent);
            return true;
        }else if (id == R.id.menu_adjust_item) {
            Intent intent = new Intent(this, AdjustInventory.class);
            startActivity(intent);
            return true;
        }else if (id == R.id.menu_remove_item) {
            Intent intent = new Intent(this, RemoveItem.class);
            startActivity(intent);
            return true;
        }else if (id == R.id.menu_logout){
            Intent intent = new Intent(this, Main.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Method to setup alert dialogs within any activity
     * @param message
     * @return
     */
    AlertDialog createDialog(String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setPositiveButton("Okay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        return builder.create();
    }

    /* Method to send the text message
     * @param item
     */
    public void sendZeroInventorySMS(String item){
        SmsManager smsManager = getSystemService(SmsManager.class);
        smsManager.sendTextMessage("5554", null, "Iventory is at Zero for item: " + item, null, null);
    }
}
